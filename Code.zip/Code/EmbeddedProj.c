sbit LCD_RS at RB0_bit;
sbit LCD_EN at RB1_bit;
sbit LCD_D4 at RB2_bit;
sbit LCD_D5 at RB3_bit;
sbit LCD_D6 at RB4_bit;
sbit LCD_D7 at RB5_bit;
sbit LCD_RS_Direction at TRISB0_bit;
sbit LCD_EN_Direction at TRISB1_bit;
sbit LCD_D4_Direction at TRISB2_bit;
sbit LCD_D5_Direction at TRISB3_bit;
sbit LCD_D6_Direction at TRISB4_bit;
sbit LCD_D7_Direction at TRISB5_bit;
char Temperature1[5];
//above code for lcd connections using lcd library
void ATD_init(void);
void fan(unsigned int p);
unsigned int ATD_read(unsigned int p);
unsigned int angle;
unsigned int Dcntr;
unsigned int Mcntr;
unsigned int result;
unsigned int tempflag;
unsigned char cntr;
float voltage;
float temperature;
unsigned int result2;
float voltage2;
unsigned int result3;
float voltage3;
unsigned int i;

void interrupt(void){

if(INTCON&0x04){
 TMR0=248; Mcntr++;

if(temperature>=30) {
 fan(250); //run fan at full speed
}
else if(temperature>=27 && temperature<30){
 fan(175); //run fan at 70% speed
}
else if(temperature>=25 && temperature<27){
 fan(125); //run fan at 50% speed
}
else{
 fan(0); //stop fan
}
INTCON = INTCON & 0xFB; // reset overflow flag bit
}
}
void myDelay(unsigned int x){
Mcntr=0;
while(Mcntr<x); // delay based on sent parameter
}

void main() {

 ATD_init(); //initializing analog to digital converter
 Lcd_Init(); //initializing lcd
 Lcd_Cmd(_LCD_CLEAR); //clearing the lcd
 Lcd_Out(1,1, "Temp="); //output "Temp=" to LCD
 TRISA=0xFF; // setting port A as input
 TRISC=0x00; // setting port C as output
 TRISD=0x80; // setting last pin on port D as input, the rest are output
 TMR0=248; // value for TMR0=248, so we get 7 counts
 OPTION_REG = 0x87; // 1:256 TMR0 prescaler, interrupt on falling edge, internal clock, port A pullups disabled
 INTCON = 0xA0; // global interrupt enabled, TMR0 enabled

 while(1){
 temperature=ATD_read(0)*0.5; //return temperature sensor reading as a number from 0-1023 and stores voltage value in variable temperature
 result2=ATD_read(1); //return reading of LDR as a number from 0-1023 and stores it in variable result2
 myDelay(20); //20ms delay
 FloatToStr(temperature, Temperature1); //turns integer value to string
 myDelay(20); // 20ms delay
 if(result2>800){  //checks if reading from LDR is above 800
  PORTD=PORTD&0xFE; //else turns of led on first pin of port D, as we are using pnp bipolar junction
 }
 else{
 PORTD=PORTD|0x01; //turns on led on first pin of port D
 }
 if(PORTD & 0x80){ //checks if reading from moisture sensor is 1 (digital input)
 PORTD=PORTD&0xFD; //turns on water pump on second pin of port D
 }
 else{
 PORTD=PORTD|0x02; // else turns off water pump
 }
 Lcd_Cmd(_LCD_CLEAR); // clears LCD
 Lcd_Out(1,1, "Temp="); //output "Temp=" to LCD
 Lcd_Out(1,7, Temperature1); // outputs temperature value to LCD
 myDelay(800); // 800ms delay
 Lcd_Cmd(_LCD_CLEAR); // clears LCD
}}

void ATD_init(void){
 ADCON0=0x41; // Fosc/16, channel 0, turn ADC on
 ADCON1=0xC0; //right justified
}


unsigned int ATD_read(unsigned int p){
 if(p==0){ //temperature sensor reading

 ADCON0=ADCON0 & 0xC7; //reset adcon0
 ADCON0=ADCON0 | 0x04; //GO, channel 0
 while(ADCON0&0x04); //as long as it's not done
 return (ADRESH<<8)|ADRESL; //return 10bit reading
 }
 else if(p==1){ //LDR reading
 ADCON0=ADCON0 & 0xC7; //reset adcon0
 ADCON0=ADCON0 | 0x0C; //GO, channel 1
 while(ADCON0&0x04); //as long as it's not done
 return (ADRESH<<8)|ADRESL; // return 10bit reading
 }

}


void fan(unsigned int p){
 T2CON = 0x27; //1:5 postscale, TMR2 on, 16 prescaler
 CCP2CON = 0x0C; //PWM mode
 PR2 = 250; // end value set to 250
 CCPR2L= p; // start value received as input
}